const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();
            
exports.handler = (event, context, callback) => {
  
  if (event.requestContext) {
    if (event.requestContext.path === '/posts/{postId}') {
      const postId = event.pathParameters.postId;
      getPost(postId).then(() => {
        // console.log('getPosts then block');
        successResponse.body = JSON.stringify(successResponse.body);
        console.log('successResponse', successResponse);
        callback(null,successResponse);
      }).catch((err) => {
        console.log('catch error block');
        console.error(err);
        errorResponse(err.message, context.awsRequestId, callback);
      });
    }
}
    
  var params = {
    TableName: 'Posts'
  };

  var responseBody = {
    data: []
  };

  var successResponse = {
    "statusCode": 201,
    "headers": {
        "Access-Control-Allow-Origin": "*"
    },
    "body": responseBody,
};

function getPost(postId) {
  console.log('postId inside of getPost', postId);
  const getPostParams = {
    TableName: 'Posts', 
    Key: {
      "PostId": postId
    }
  };
  function getLimitedPostsForGroupName(groupName, dealershipName, offset = 0) {
    const POSTS_QUERY_LIMIT = 3;
    const getLimitedPostParams = { 
      TableName: 'ForumCF',
      Key: {
        'Group': groupName,
        'Dealership': dealershipName
      },
      Limit: POSTS_QUERY_LIMIT,
      ReturnConsumedCapacity: TOTAL
    };
    // use last evaluated key to advance the limit
    ddb.query(params, function(error, data) {
      if (error) {
        console.log('error', error);
      } else {
        console.log('data returned by query', data);
      }
    })
  }
  return ddb.get(getPostParams, function(error, data) {
    if (error) {
      console.log('error on getItem', error);
      responseBody.data.push('Error getting item');
    } else {
      responseBody.data.push(data);
    }
  }).promise();
}

// Version control at its finest...
// function getPosts() {
//   return ddb.scan(params, function(error, results) {
//     if (error) {
//       console.log('error', error);
//       responseBody.data.push('Error');
//     } else {
//       // console.log('Query succeeded. results', results);
//       results.Items.forEach(function(item) {
//         responseBody.data.push(item);
//       });
//     }
//   }).promise();
// }

function getPosts() {
  return dbb.scan(params, scanCallback).promise();
}

function scanCallback(error, results) {
  if (error) {
      console.log('error', error);
      responseBody.data.push('Error');
  }
  else {
    // console.log('Query succeeded. results', results);
    results.Items.forEach(function(item) {
      responseBody.data.push(item);
    });
  }
  // Pagination 
  if (!typeof results.LastEvaluatedKey) {
      // Initiate the scan query with the last returned key
      params.ExclusiveStartKey = results.LastEvaluatedKey;
      ddb.scan(params, scanCallback);
  }
}

function getPostsPaginated() {
}

function errorResponse(errorMessage, awsRequestId, callback) {
  callback(null, {
    statusCode: 500,
    body: JSON.stringify({
      Error: errorMessage,
      Reference: awsRequestId,
    }),
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
  });
}

getPosts().then(() => {
  // console.log('getPosts then block');
  successResponse.body = JSON.stringify(successResponse.body);
  console.log('successResponse', successResponse);
  callback(null,successResponse);
}).catch((err) => {
  console.log('catch error block');
  console.error(err);
  errorResponse(err.message, context.awsRequestId, callback);
});
  
};
            